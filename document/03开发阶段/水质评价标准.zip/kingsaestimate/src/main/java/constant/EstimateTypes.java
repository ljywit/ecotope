package constant;

/**
 * Created by lxf on 18/9/14.
 */
public interface EstimateTypes {
    public static final short QUALIFIED = 0;

    public static final short CLASS_ONE = 1;

    public static final short CLASS_TWO = 2;

    public static final short CLASS_THREE = 3;

    public static final short CLASS_FOUR = 4;

    public static final short CLASS_FIVE = 5;

    public static final short CLASS_SIX = 6;

    public static final short UN_QUALIFIED = 7;
}
