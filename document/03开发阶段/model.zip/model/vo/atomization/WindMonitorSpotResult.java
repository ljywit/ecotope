package com.rdc.kingsa.model.vo.atomization;

/**
 * Created by lxf on 18/8/2.
 */
public class WindMonitorSpotResult {
    private String monitorSpotId;
    private String spotName;
    private String spotCode;

    public String getMonitorSpotId() {
        return monitorSpotId;
    }

    public void setMonitorSpotId(String monitorSpotId) {
        this.monitorSpotId = monitorSpotId;
    }

    public String getSpotName() {
        return spotName;
    }

    public void setSpotName(String spotName) {
        this.spotName = spotName;
    }

    public String getSpotCode() {
        return spotCode;
    }

    public void setSpotCode(String spotCode) {
        this.spotCode = spotCode;
    }
}
