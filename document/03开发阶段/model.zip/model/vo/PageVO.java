package com.rdc.kingsa.model.vo;

/**
 * Created by lxf on 18/8/16.
 */
public class PageVO {
    private Long total;
    private Object results;

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Object getResults() {
        return results;
    }

    public void setResults(Object results) {
        this.results = results;
    }
}
