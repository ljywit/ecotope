package com.rdc.kingsa.model.vo.climate;

/**
 * Created by lxf on 18/8/4.
 */
public class ClimateSpotVO {
    private String spotId;

    private String spotName;

    public String getSpotId() {
        return spotId;
    }

    public void setSpotId(String spotId) {
        this.spotId = spotId;
    }

    public String getSpotName() {
        return spotName;
    }

    public void setSpotName(String spotName) {
        this.spotName = spotName;
    }
}
