package com.rdc.kingsa.model.po.doc;

/**
 * Created by lxf on 18/8/9.
 */
public class DocFileTagName {
    private String fileId;
    private String tagName;

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }
}
